/**
 * ****************************************************************************
 *  Copyright (c) 2013 IBM Corp.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * *****************************************************************************
 */
package com.acmeair.web;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import org.json.simple.JSONObject;
import com.acmeair.service.AuthService;
import com.acmeair.service.CustomerService;

@Path("/login")
public class LoginRESTServer {

    public static String SESSIONID_COOKIE_NAME = "acmeair_sessionid";

    @Inject
    AuthService authService;

    @Inject
    CustomerService customerService;

    @POST
    @Consumes({ "application/x-www-form-urlencoded" })
    @Produces("text/plain")
    public Response login(@FormParam("login") String login, @FormParam("password") String password) {
        try {
            boolean validCustomer = customerService.validateCustomer(login, password);
            if (!validCustomer) {
                return Response.status(Response.Status.FORBIDDEN).build();
            }
            JSONObject sessionJson = authService.createSession(login);
            return Response.ok("logged in").header("Set-Cookie", SESSIONID_COOKIE_NAME + "=" + sessionJson.get("_id") + "; Path=/").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GET
    @Path("/logout")
    @Produces("text/plain")
    public Response logout(@QueryParam("login") String login, @CookieParam("acmeair_sessionid") String sessionid) {
        try {
            if (sessionid == null) {
                System.out.println("sessionid is null");
                return Response.status(Response.Status.FORBIDDEN).build();
            }
            if (sessionid.equals("")) {
                System.out.println("sessionid is empty");
            } else {
                authService.invalidateSession(sessionid);
            }
            return Response.ok("logged out").build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    public static void setSESSIONID_COOKIE_NAME(String SESSIONID_COOKIE_NAME) {
        LoginRESTServer.SESSIONID_COOKIE_NAME = SESSIONID_COOKIE_NAME;
    }

    public static String getSESSIONID_COOKIE_NAME() {
        return SESSIONID_COOKIE_NAME;
    }

    public void setAuthService(AuthService authService) {
        this.authService = authService;
    }

    public AuthService getAuthService() {
        return authService;
    }

    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    public CustomerService getCustomerService() {
        return customerService;
    }
}

