/*
 * Copyright (c) 2012, Mayocat <hello@mayocat.org>
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
package org.mayocat.entity;

/**
 * @version $Id: f20c861aff59cab35e3519a34c1df2368e7a5839 $
 */
public interface LoadingOption {

    public int id = 0;

    public static LoadingOption getObject(int id) {
        return null;
    }
}

